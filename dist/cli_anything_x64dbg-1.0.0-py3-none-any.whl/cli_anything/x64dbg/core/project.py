from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass
class DebugTarget:
    executable: str = ""
    arguments: str = ""
    cwd: str = ""
    attached_pid: int | None = None

    def normalized(self) -> "DebugTarget":
        return DebugTarget(
            executable=str(Path(self.executable).expanduser()) if self.executable else "",
            arguments=self.arguments,
            cwd=str(Path(self.cwd).expanduser()) if self.cwd else "",
            attached_pid=self.attached_pid,
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def project_summary(target: DebugTarget) -> str:
    parts: list[str] = []
    if target.executable:
        parts.append(target.executable)
    if target.attached_pid is not None:
        parts.append(f"pid={target.attached_pid}")
    if target.arguments:
        parts.append(f"args={target.arguments}")
    if target.cwd:
        parts.append(f"cwd={target.cwd}")
    return ", ".join(parts) if parts else "no target"
