from __future__ import annotations

import json
from typing import Any

import click


def build_result(ok: bool, action: str, command: str | None = None, output: str = "", **extra: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "ok": ok,
        "action": action,
        "command": command,
        "output": output,
    }
    payload.update(extra)
    return payload


def emit(ctx: click.Context, payload: dict[str, Any], human: str | None = None) -> None:
    if ctx.obj.get("json"):
        click.echo(json.dumps(payload, indent=2, ensure_ascii=False))
        return
    if human is not None:
        click.echo(human)
        return
    output = payload.get("output")
    if output:
        click.echo(output.rstrip())
    else:
        click.echo(payload.get("action", "ok"))
